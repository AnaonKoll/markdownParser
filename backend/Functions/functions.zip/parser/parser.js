const parser = () => {
    return {
        toHtml: (data, template) => {
            let dataParsed = data;

            return dataParsed;
        },

        toMediawiki: (data) => {
            let dataParsed = data;

            return dataParsed;
        }
    }
};

module.exports = parser();